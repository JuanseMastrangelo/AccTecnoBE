

<?php $__env->startSection('content'); ?>
<div>
    <estadisticas-main-component transacciones-route="<?php echo e(route('getAllCompras')); ?>"></estadisticas-main-component>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Trabajo\AccTecnoWeb\resources\views/estadisticas/main/stats-main.blade.php ENDPATH**/ ?>