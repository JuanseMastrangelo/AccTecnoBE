<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MarketPlace</title>
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    </head>
    <body>
        
        
        <?php $__env->startSection('content'); ?>
            <div class="container d-flex justify-content-center align-items-center" style="height: 50vh;">
                <div class="d-block text-center">
                    <img src="<?php echo e(asset('images/think.svg')); ?>" class="mb-5" width="150" />
                    <h3>Inicia sesion para comenzar a ver las estadísticas!</h3>
                </div>
            </div>
        <?php $__env->stopSection(); ?>
        
    </body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Trabajo\AccTecnoWeb\resources\views/welcome.blade.php ENDPATH**/ ?>