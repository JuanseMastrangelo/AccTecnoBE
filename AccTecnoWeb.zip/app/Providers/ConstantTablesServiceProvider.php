<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class ConstantTablesServiceProvider extends ServiceProvider
{
    const GUARD_ADMIN = 'admin';
}
