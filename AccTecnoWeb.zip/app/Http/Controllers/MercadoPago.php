<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use MP;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\ComprasModel;

class MercadoPago extends Controller {


    function __construct() {
        MP::sandbox_mode(false);
    }


    // Devuelve datos sobre la compra
    public function createPreference(Request $request) {
        $preferenceData = [
            'items' => $request[0],
            "additional_info" => json_encode($request[1]),
            'shipments' => [
                'mode' => 'not_specified',
                'dimensions' => '10x10x10,300',
                'cost' => 670
            ],
            'payer' => [
                "name" => $request[1]['userData']['name'],
                "email" => $request[1]['userData']['email']."ar", // QUITAR .AR
            ],
            "notification_url" => "http://localhost:3000/api/notificatePay",
        ];

        return MP::create_preference($preferenceData);
    }


    
    public function notificationIPN(Request $request) {

        $task = ComprasModel::create([
            'status' => true,
            'userData' => 'asd',
            'items' => '[]',
            'collectorId' => '123'
        ]);
        return $request;
    }

}
