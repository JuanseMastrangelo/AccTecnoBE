<?php

return [
    'failed' => 'Usuario o contraseña incorrectos.',
    'throttle' => 'Demasiados intentos fallidos. Intente nuevamente en :seconds segundos.',

];
