
@extends('layouts.app')

@section('content')
    <cargar-productos-component></cargar-productos-component>
@endsection
