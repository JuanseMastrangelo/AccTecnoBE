
@extends('layouts.app')

@section('content')
    <cargar-categorias-component></cargar-categorias-component>
@endsection
