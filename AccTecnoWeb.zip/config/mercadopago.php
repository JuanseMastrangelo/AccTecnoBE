<?php

return [
	'app_id'     => env('MP_APP_ID', 'APP_USR-3719832131520913-071518-227e4aa335b2e2c8a12559e3bbc6eee9-207712437'),
	'app_secret' => env('MP_APP_SECRET', 'aXHZELjsHZmxSmTFOVIQJcYhqbdVtEUL')
];